#include <stdio.h>
#include <time.h>
#include "matrix_dynamic.h"

int main()
{
	srand(time(NULL));
	matrix MyMatrix;
	MyMatrix = create_empty(2,3);
	for(int i = 0; i < MyMatrix.row_dim ; i++)
		for(int j = 0; j < MyMatrix.col_dim ; j++)
		{
			int val = rand() % 100;
			MyMatrix.element[i][j] = val;
		}
	matrix_print(MyMatrix);	
	MyMatrix = transpose_matrix(MyMatrix);
	matrix_print(MyMatrix);
}

