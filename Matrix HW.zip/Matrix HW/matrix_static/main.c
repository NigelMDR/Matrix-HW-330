#include <stdio.h>
#include "matrix_static.h"

int main()
{
	matrix MyMatrix;
	MyMatrix = create_empty(2,3);
	for(int i = 0; i < MyMatrix.row_dim ; i++)
		for(int j = 0; j < MyMatrix.col_dim ; j++)
		{
			int val = rand()%1000;
			MyMatrix.element[i][j] = val;
		}
	matrix_print(MyMatrix);	
	MyMatrix = transpose_matrix(MyMatrix);
	matrix_print(MyMatrix);
}

